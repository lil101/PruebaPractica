/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.List;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

/**
 *
 * @author Oscar
 */
public class TMLaboratorio implements TableModel {

    private List<Laboratorio> lbt;

    public TMLaboratorio(List<Laboratorio> Lista) {
        lbt = Lista;
    }

    @Override
    public int getRowCount() {
        return lbt.size();
    }

    @Override
    public int getColumnCount() {
        return 11;
    }

    @Override
    public String getColumnName(int columnIndex) {

        String titulo = null;
        switch (columnIndex) {
            case 0: {
                titulo = "Nro_de_ID";
                break;
            }
            case 1: {
                titulo = "Nombres";
                break;
            }
            case 2: {
                titulo = "Apellidos";
                break;
            }
            case 3: {
                titulo = "Campus";
                break;
            }
            case 4: {
                titulo = "Laboratorio";
                break;
            }
            case 5: {
                titulo = "Carrera";
                break;
            }
            case 6: {
                titulo = "Modulo";
                break;
            }
            case 7: {
                titulo = "Materia";
                break;
            }
            case 8: {
                titulo = "Fecha";
                break;
            }
            case 9: {
                titulo = "Hora_Ingreso";
                break;
            }
            case 10: {
                titulo = "Hora_Salida";
                break;
            }
        }
        return titulo;    
        }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Laboratorio ldt = lbt.get(rowIndex);
        String valor = null;

        switch (columnIndex) {
            case 0: {
                valor = ldt.getNro_de_ID();
                break;
            }
            case 1: {
                valor = ldt.getNombres();
                break;
            }
            case 2: {
                valor = ldt.getApellidos();
                break;
            }
            case 3: {
                valor = ldt.getCampus();
                break;
            }
            case 4: {
                valor = ldt.getLaboratorio();
                break;
            }
            case 5: {
                valor = ldt.getCarrera();
                break;
            }
            case 6: {
                valor = ldt.getModulo();
                break;
            }
            case 7: {
                valor =ldt.getMateria();
                break;
            }
            case 8: {
                valor = ldt.getFecha();
                break;
            }
            case 9: {
                valor = ldt.getHora_Ingreso();
                break;
            }
            case 10: {
                valor = ldt.getHora_Salida();
                break;
            }
        }
        return valor;

    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        //sirve si en caso modifica de la tabla
    }

    @Override
    public void addTableModelListener(TableModelListener l) {

    }

    @Override
    public void removeTableModelListener(TableModelListener l) {

    }

}
