/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Oscar
 */
public class ConeccionLaboratorio {
    
    public static ArrayList<Laboratorio> listaLaboratorio;
    
    public static void guardarUsoLaboratorio(Laboratorio laboratorio) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //direccion de la base de datos
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/registrolaboratorios", "root", "root");
            System.out.println("Conexion establecida!");
            Statement sentencia = (Statement) conexion.createStatement();
            int insert = sentencia.executeUpdate("insert into laboratorio values("
                    + "'" + laboratorio.getNro_de_ID()
                    + "','" + laboratorio.getNombres()
                    + "','" + laboratorio.getApellidos()
                    + "','" + laboratorio.getCampus()
                    + "','" +laboratorio.getLaboratorio()
                    + "','" + laboratorio.getCarrera()
                    + "','" + laboratorio.getModulo()
                    + "','" + laboratorio.getMateria()
                    + "','" + laboratorio.getFecha()
                    + "','" + laboratorio.getHora_Ingreso()
                    + "','" + laboratorio.getHora_Salida()
                    + "')");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.println("Error en la conexion" + ex);
        }
    }
    //con este metodo buscamos los datos guardados
    public static Laboratorio buscarLaboratorio(String Nro_de_ID) {
        //ponemos este método a la base de datos
        Laboratorio lbt = new Laboratorio();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/registrolaboratorios", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            ResultSet necesario = sentencia.executeQuery("select * from docente where Nro_de_ID ='" + Nro_de_ID + "'");

            while (necesario.next()) {

                String ced = necesario.getString("Nro_de_ID");
                String nomb = necesario.getString("Nombres");
                String ape = necesario.getString("Apellidos");
//                String cam = necesario.getString("Campus");
//                String lab = necesario.getString("Laboratorio");
//                String carr = necesario.getString("Carrera");
//                String mod = necesario.getString("Modulo");
//                String mta = necesario.getString("Materia");
//                String fecha = necesario.getString("Fecha");
//                String HI = necesario.getString("Hora_Ingreso");
//                String HS = necesario.getString("Hora_Salida");

                lbt.setNro_de_ID(ced);
                lbt.setNombres(nomb);
                lbt.setApellidos(ape);
//                lbt.setCampus(cam);
//                lbt.setLaboratorio(lab);
//                lbt.setCarrera(carr);
//                lbt.setModulo(mod);
//                lbt.setMateria(mta);
//                lbt.setFecha(fecha);
//                lbt.setHora_Ingreso(HI);
//                lbt.setHora_Salida(HS);
            }
            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
        return lbt;
    }
    
    //EDITAR
    
       public static void editarLaboratorio(Laboratorio laboratorio) {
        //metimos este método a la base de datos
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/registrolaboratorios", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("update laboratorio set "
                    
                    + "Nro_de_ID='" + laboratorio.getNro_de_ID()
                    + "',Nombres='" + laboratorio.getNombres()
                    + "',Apellidos='" + laboratorio.getApellidos()
                    + "',Campus='" + laboratorio.getCampus()
                    + "',Laboratorio='" + laboratorio.getLaboratorio()
                    + "',Carrera='" + laboratorio.getCarrera()
                    + "',Modulo='" +laboratorio.getModulo()
                    + "',Materia='" +laboratorio.getMateria()
                    + "',Fecha='" + laboratorio.getFecha()
                    + "',Hora_Ingreso='" + laboratorio.getHora_Ingreso()
                    + "',Hora_salida='" + laboratorio.getHora_Salida()
                    
                    + "'where Nro_de_ID='" + laboratorio.getNro_de_ID()+"';");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
        
    }
         //metodo para eliminar un dato
     public static void eliminar(String Nro_de_ID) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/registrolaboratorios", "root", "root");
            System.out.print("Conexion Establecida");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("delete from laboratorio where Nro_de_ID = '" + Nro_de_ID + "'");

            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }

    }
     // este metodo nos retorna una lista cono los datos ingresados 
      public static ArrayList cargarLaboratorio() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/registrolaboratorios", "root", "root");
            System.out.printf("conexion establesida");
            Statement sentencia = conexion.createStatement();
            ResultSet necesario = sentencia.executeQuery("select * from laboratorio");

            Laboratorio laboratorio;

            listaLaboratorio = new ArrayList<>();
            while (necesario.next()) {

                String Nro_de_ID = necesario.getString("Nro_de_ID");
                String nombres = necesario.getString("Nombres");
                String apellidos = necesario.getString("Apellidos");
                String campus = necesario.getString("Campus");
                String labora = necesario.getString("Laboratorio");
                String carrera = necesario.getString("Carrera");
                String modulo = necesario.getString("Modulo");
                String materia = necesario.getString("Materia");
                String fecha = necesario.getString("Fecha");
                String horaIngreso = necesario.getString("Hora_Ingreso");
                String horaSalida = necesario.getString("Hora_Salida");

                laboratorio = new Laboratorio();

                laboratorio.setNro_de_ID(Nro_de_ID);
                laboratorio.setNombres(nombres);
                laboratorio.setApellidos(apellidos);
                laboratorio.setCampus(campus);
                laboratorio.setLaboratorio(labora);
                laboratorio.setCarrera(carrera);
                laboratorio.setModulo(modulo);
                laboratorio.setMateria(materia);
                laboratorio.setFecha(fecha);
                laboratorio.setHora_Ingreso(horaIngreso);
               laboratorio.setHora_Salida(horaSalida);
                
                listaLaboratorio.add(laboratorio);
                
            }
            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.println("Error en la conexion" + ex);
        }
        return listaLaboratorio;
    }
   
}
       

