/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Modelo.ConeccionLaboratorio;
import Vista.RegistroIngreso;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Oscar
 */
public class OyenteEliminarLaboratorio implements ActionListener {
//llamanos las clases 

    ConeccionLaboratorio cnlb;
    RegistroIngreso reging;

    public OyenteEliminarLaboratorio(RegistroIngreso reging) {

        this.reging = reging;

    }

    public void actionPerformed(ActionEvent e) {

//enviamos un mensaje de confirmacion
        int resp = JOptionPane.showConfirmDialog(null, "Eliminar Datos", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (resp == JOptionPane.YES_OPTION) {
            cnlb.eliminar(reging.eliminarDocente());
            JOptionPane.showMessageDialog(null, "Datos eliminados");
            reging.limpiarCamposLaboratorio();

        } else if (resp == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "Los  datos no ha sido eliminado");
        }
    }
}
