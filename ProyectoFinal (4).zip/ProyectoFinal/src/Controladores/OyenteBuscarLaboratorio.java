/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Modelo.ConeccionLaboratorio;
import Modelo.Laboratorio;
import Vista.RegistroIngreso;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Oscar
 */
public class OyenteBuscarLaboratorio implements ActionListener {
//llamos las clases 
    Laboratorio lbt;
    ConeccionLaboratorio cnlb;
    RegistroIngreso reging;

    public OyenteBuscarLaboratorio(RegistroIngreso reging) {
        this.reging = reging;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        lbt = cnlb.buscarLaboratorio(reging.verificarLaboratorio());
        // no esta llamar

        if (lbt.getNro_de_ID() == null) {
            //si no se encuntra registado havilita los campos parapoder registrar-->>

            reging.bloquearCampos();

            JOptionPane.showMessageDialog(null, "Datos no registardos");
            int resp = JOptionPane.showConfirmDialog(null, "Registar datos ", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                reging.desbloquearCampos();
            } else if (resp == JOptionPane.NO_OPTION) {
                reging.bloquearCampos();
                reging.limpiarCamposLaboratorio();
            }

        } else {
            //si se encuentra registado lo llama -->>

            reging.desbloquearCampos();
           reging.limpiarCamposLaboratorio();
            //reging.bloquearCampos();
            reging.cargarCampos(lbt);

        }
    }

}
