/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Modelo.ConeccionLaboratorio;
import Modelo.Laboratorio;
import Vista.RegistroIngreso;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Oscar
 */
public class OyenteEditarLaboratorio implements ActionListener {
//llamos las clases
   Laboratorio lbt;
    ConeccionLaboratorio cnlb;
    RegistroIngreso reging;

    public OyenteEditarLaboratorio(RegistroIngreso reging) {
        this.reging = reging;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        reging.desbloquearCampos();
     lbt = reging.guardarLaboratorio();
        cnlb.editarLaboratorio(lbt);
        JOptionPane.showMessageDialog(null, "Sus cambios han sido registrados ");
        reging.limpiarCamposLaboratorio();
    }

}
