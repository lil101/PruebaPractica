/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import FondoPanel.FondoPanel;
import Controladores.OyenteBuscarDocente;
import Controladores.OyenteBuscarEstudiante;
import Controladores.OyenteEditarEstudiante;
import Controladores.OyenteEliminarEstudiante;
import Controladores.OyenteRegistrarEstudiante;
import Modelo.Estudiante;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Oscar
 */
public class VentanaEstudiante extends JFrame {

    JTextField txtfCedula = new JTextField(20);
    JTextField txtfNombres = new JTextField(20);
    JTextField txtfApellidos = new JTextField(20);
    JTextField txtfTelefono = new JTextField(20);
    JTextField txtfCorreo = new JTextField(20);
    
    JButton btnGuardar = new JButton("Registrarse");
    JButton btnBuscar = new JButton("Buscar");
    JButton btnEditar = new JButton("Editar");
    JButton btnEliminar = new JButton("Eliminar");
    JButton btnSalir = new JButton("Salir");
    JButton btndesbloquear = new JButton("Habilitar");

    JPanel panel = new JPanel();
    FondoPanel fondo = new FondoPanel();
    Estudiante est = new Estudiante();

    public VentanaEstudiante() {

        super("DATOS PERSONALES DEL ESTUDIANTE");
        setSize(500, 500);
        setLocation(200, 200);
        setResizable(true);
        dispose();
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        AgregarComponentes();
        bloquearCampos();

    }

    public void AgregarComponentes() {

        getContentPane().add(fondo);
        fondo.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        fondo.setLayout(new GridBagLayout());
        GridBagConstraints a = new GridBagConstraints();

        a.anchor = GridBagConstraints.WEST;
        a.insets = new Insets(5, 10, 5, 10);

        a.gridx = 0;
        a.gridy = 0;
        fondo.add(txtfCedula, a);
        fondo.add(new JLabel("Cedula"), a);
        a.gridx = 1;
        fondo.add(txtfCedula, a);

        a.gridx = 2;
        fondo.add(btnBuscar, a);
        btnBuscar.addActionListener(new OyenteBuscarEstudiante(this));//damos la accion al boton
        

        a.gridx = 0;
        a.gridy = 1;
        fondo.add(txtfNombres, a);
        fondo.add(new JLabel("Nombres"), a);
        a.gridx = 1;
        fondo.add(txtfNombres, a);

        a.gridx = 2;
        fondo.add(btndesbloquear, a);
        btndesbloquear.addActionListener(new havilitar());//damos la accion al boton
        

        a.gridx = 0;
        a.gridy = 2;
        fondo.add(txtfApellidos, a);
        fondo.add(new JLabel("Apellidos"), a);
        a.gridx = 1;
        fondo.add(txtfApellidos, a);

        a.gridx = 0;
        a.gridy = 3;
        fondo.add(txtfTelefono, a);
        fondo.add(new JLabel("Telefono"), a);
        a.gridx = 1;
        fondo.add(txtfTelefono, a);
        
        a.gridx = 0;
        a.gridy = 4;
        fondo.add(txtfCorreo, a);
        fondo.add(new JLabel("Correo"), a);
        a.gridx = 1;
        fondo.add(txtfCorreo, a);
      
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.insets = new Insets(20, 0, 20, 0);

        c.gridx = 0;
        c.gridy = 10;
        panel.add(btnGuardar, c);
        c.gridx = 0;
        fondo.add(btnGuardar, c);
        btnGuardar.addActionListener(new OyenteRegistrarEstudiante(this));//damos la accion al boton
        

        c.gridx = 0;
        c.gridy = 10;
        panel.add(btnEditar, c);
        c.gridx = 1;
        fondo.add(btnEditar, c);
        btnEditar.addActionListener(new OyenteEditarEstudiante(this));//damos la accion al boton

        c.gridx = 0;
        c.gridy = 10;
        panel.add(btnEliminar, c);
        c.gridx = 2;
        fondo.add(btnEliminar, c);
        btnEliminar.addActionListener(new OyenteEliminarEstudiante(this));//damos la accion al boton

        c.gridx = 2;
        c.gridy = 11;
        panel.add(btnSalir, c);
        c.gridx = 1;
        fondo.add(btnSalir, c);
        btnSalir.addActionListener(new OyenteSalir());//damos la accion al boton

    }

    public Estudiante guradarEstudiante() {

        est = new Estudiante();

        est.setNro_de_ID(txtfCedula.getText());
        est.setNombres(txtfNombres.getText());
        est.setApellidos(txtfApellidos.getText());
        est.setTelefono(txtfTelefono.getText());
        est.setCorreo(txtfCorreo.getText());

        return est;
    }

    public void limpiarCamposEstudinates() {
        txtfCedula.setText("");
        txtfNombres.setText("");
        txtfApellidos.setText("");
        txtfTelefono.setText("");
        txtfCorreo.setText("");
    }

    public void bloquearCampos() {
        //  txtfCedula.setEditable(false);
        txtfNombres.setEditable(false);
        txtfApellidos.setEditable(false);
        txtfTelefono.setEditable(false);
        txtfCorreo.setEditable(false);

    }

    public void desbloquearCampos() {
        txtfCedula.setEditable(true);
        txtfNombres.setEditable(true);
        txtfApellidos.setEditable(true);
        txtfTelefono.setEditable(true);
        txtfCorreo.setEditable(true);
    }

    public String verificarEstudiante() {
        return txtfCedula.getText();
    }

    public void cargarCampos(Estudiante estudiante) {

        txtfCedula.setText(estudiante.getNro_de_ID());
        txtfNombres.setText(estudiante.getNombres());
        txtfApellidos.setText(estudiante.getApellidos());
        txtfTelefono.setText(estudiante.getTelefono());
        txtfCorreo.setText(estudiante.getCorreo());
    }

    public String eliminarEstudiante() {
        return txtfCedula.getText();
    }

    public class OyenteSalir implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

            if (e.getSource() == btnSalir) {
                dispose();
            }
        }
    }

    public class havilitar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            if (e.getSource() == btndesbloquear) {
                desbloquearCampos();

            }

//    public static void main(String[] args) {
//        new VentanaEstudiante();
//    }
        }
    }
}
