/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controladores.OyenteBuscarDocente;
import Controladores.OyenteBuscarLaboratorio;
import Controladores.OyenteEditarDocente;
import Controladores.OyenteEditarLaboratorio;
import Controladores.OyenteEliminarDocente;
import Controladores.OyenteEliminarLaboratorio;
import Controladores.OyenteRegistarDocente;
import Controladores.OyenteRegistroLaboratorio;
import FondoPanel.FondoPanel;
import Modelo.Laboratorio;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Oscar
 */
public final class RegistroIngreso extends JFrame {

    JTextField txtfCedula = new JTextField(20);
    JTextField txtfNombres = new JTextField(20);
    JTextField txtfApellidos = new JTextField(20);
    JComboBox cmbCampus = new JComboBox();
    JComboBox cmbLaboratorio = new JComboBox();
    JTextField txtfCarrera = new JTextField(20);
    JComboBox cmbModulo = new JComboBox();
    JTextField txtfMateria = new JTextField(20);
    JTextField txtfFecha = new JTextField(20);
    JTextField txtfHoraIngreso = new JTextField(20);
    JTextField txtfHoraSalida = new JTextField(20);

    JButton btnGuardar = new JButton("Registrarse");
    JButton btnBuscar = new JButton("Buscar");
    JButton btnEditar = new JButton("Editar");
    JButton btnEliminar = new JButton("Eliminar");
    JButton btnSalir = new JButton("Salir");
    JButton btndesbloquear = new JButton("Habilitar");

    FondoPanel fondo = new FondoPanel();
    JPanel panel = new JPanel();
    Laboratorio lbto = new Laboratorio();

    public RegistroIngreso() {

        super("RESGISTRO DE USO DE LABORATORIO");
        setSize(600, 600);
        setLocation(300, 100);
        setResizable(true);
        dispose();
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        AgregarComponentes();
        bloquearCampos();

    }

    public void AgregarComponentes() {

        getContentPane().add(fondo);
        fondo.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        fondo.setLayout(new GridBagLayout());
        GridBagConstraints a = new GridBagConstraints();

        a.anchor = GridBagConstraints.WEST;
        a.insets = new Insets(5, 10, 5, 10);

        a.gridx = 0;
        a.gridy = 0;
        fondo.add(txtfCedula, a);
        fondo.add(new JLabel("Cedula"), a);
        a.gridx = 1;
        fondo.add(txtfCedula, a);

        a.gridx = 2;
        fondo.add(btnBuscar, a);
        btnBuscar.addActionListener(new OyenteBuscarLaboratorio(this));//damos la accion al boton

        a.gridx = 0;
        a.gridy = 1;
        fondo.add(txtfNombres, a);
        fondo.add(new JLabel("Nombres"), a);
        a.gridx = 1;
        fondo.add(txtfNombres, a);

        a.gridx = 2;
        fondo.add(btndesbloquear, a);
        btndesbloquear.addActionListener(new RegistroIngreso.havilitar());//damos la accion al boton

        a.gridx = 0;
        a.gridy = 2;
        fondo.add(txtfApellidos, a);
        fondo.add(new JLabel("Apellidos"), a);
        a.gridx = 1;
        fondo.add(txtfApellidos, a);

        Vector vCampus = new Vector();
        vCampus.addElement("");
        vCampus.addElement("ISTL VILCABAMBA");
        vCampus.addElement("ISTL LOJA");
        vCampus.addElement("OTROS");
        cmbCampus = new JComboBox(vCampus);
        cmbCampus.setPreferredSize(new Dimension(225, 25));
        a.gridx = 0;
        a.gridy = 3;
        fondo.add(new JLabel("Campus"), a);
        a.gridx = 1;
        fondo.add(cmbCampus, a);
        a.gridx = 0;
        a.gridy = 4;

        Vector vLaboratorio = new Vector();
        vLaboratorio.addElement("");
        vLaboratorio.addElement("Laboratorio de Informatica");
        vLaboratorio.addElement("Laboratorio de Idiomas");
        cmbLaboratorio = new JComboBox(vLaboratorio);
        cmbLaboratorio.setPreferredSize(new Dimension(225, 25));
        a.gridx = 0;
        a.gridy = 4;
        fondo.add(new JLabel("Laboratorio"), a);
        a.gridx = 1;
        fondo.add(cmbLaboratorio, a);
        a.gridx = 0;
        a.gridy = 4;

        a.gridx = 0;
        a.gridy = 5;
        fondo.add(txtfCarrera, a);
        fondo.add(new JLabel("Carrera"), a);
        a.gridx = 1;
        fondo.add(txtfCarrera, a);

        Vector vModulo = new Vector();
        vModulo.addElement("");
        vModulo.addElement("I");
        vModulo.addElement("II");
        vModulo.addElement("III");
        vModulo.addElement("IV");
        vModulo.addElement("V");
        cmbModulo = new JComboBox(vModulo);
        cmbModulo.setPreferredSize(new Dimension(225, 25));
        a.gridx = 0;
        a.gridy = 6;
        fondo.add(new JLabel("Modulo"), a);
        a.gridx = 1;
        fondo.add(cmbModulo, a);
        a.gridx = 0;
        a.gridy = 6;

        a.gridx = 0;
        a.gridy = 7;
        fondo.add(txtfMateria, a);
        fondo.add(new JLabel("Materia"), a);
        a.gridx = 1;
        fondo.add(txtfMateria, a);

        a.gridx = 0;
        a.gridy = 8;
        fondo.add(txtfFecha, a);
        fondo.add(new JLabel("Fecha"), a);
        a.gridx = 1;
        fondo.add(txtfFecha, a);

        a.gridx = 0;
        a.gridy = 9;
        fondo.add(txtfHoraIngreso, a);
        fondo.add(new JLabel("Hora de Ingreso"), a);
        a.gridx = 1;
        fondo.add(txtfHoraIngreso, a);

        a.gridx = 0;
        a.gridy = 10;
        fondo.add(txtfHoraSalida, a);
        fondo.add(new JLabel("Hora de Salida"), a);
        a.gridx = 1;
        fondo.add(txtfHoraSalida, a);

        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.insets = new Insets(20, 0, 20, 0);

        c.gridx = 0;
        c.gridy = 11;
        panel.add(btnGuardar, c);
        c.gridx = 0;
        fondo.add(btnGuardar, c);
         btnGuardar.addActionListener(new OyenteRegistroLaboratorio(this));//damos la accion al boton

        c.gridx = 0;
        c.gridy = 11;
        panel.add(btnEditar, c);
        c.gridx = 1;
        fondo.add(btnEditar, c);
        btnEditar.addActionListener(new OyenteEditarLaboratorio(this));//damos la accion al boton
        c.gridx = 0;
        c.gridy = 11;
        panel.add(btnEliminar, c);
        c.gridx = 2;
        fondo.add(btnEliminar, c);
        btnEliminar.addActionListener(new OyenteEliminarLaboratorio(this));//damos la accion al boton

        c.gridx = 1;
        c.gridy = 12;
        panel.add(btnSalir, c);
        c.gridx = 1;
        fondo.add(btnSalir, c);
        btnSalir.addActionListener(new RegistroIngreso.OyenteSalir());//damos la accion al boton

    }
    
    public Laboratorio guardarLaboratorio() {

        lbto = new Laboratorio();

        lbto.setNro_de_ID(txtfCedula.getText());
        lbto.setNombres(txtfNombres.getText());
        lbto.setApellidos(txtfApellidos.getText());
        lbto.setCampus((String) cmbCampus.getSelectedItem());
        lbto.setLaboratorio((String) cmbLaboratorio.getSelectedItem());
        lbto.setCarrera((String) txtfCarrera.getText());
        lbto.setModulo((String) cmbModulo.getSelectedItem());
        lbto.setMateria((String) txtfMateria.getText());
        lbto.setFecha(txtfFecha.getText());
        lbto.setHora_Ingreso(txtfHoraIngreso.getText());
        lbto.setHora_Salida(txtfHoraSalida.getText());

        return lbto;
    }
     public void limpiarCamposLaboratorio() {
        txtfCedula.setText("");
        txtfNombres.setText("");
        txtfApellidos.setText("");
        cmbCampus.setSelectedIndex(0);
        cmbLaboratorio.setSelectedIndex(0);
        txtfCarrera.setText("");
        cmbModulo.setSelectedIndex(0);
        txtfMateria.setText("");
        txtfFecha.setText("");
        txtfHoraIngreso.setText("");
        txtfHoraSalida.setText("");
    }

    public void bloquearCampos() {
        //  txtfCedula.setEditable(false);
        txtfNombres.setEditable(false);
        txtfApellidos.setEditable(false);
        cmbCampus.setEditable(false);
        cmbLaboratorio.setEditable(false);
        txtfCarrera.setEditable(false);
        cmbModulo.setEditable(false);
        txtfMateria.setEditable(false);
        txtfFecha.setEditable(false);
        txtfHoraIngreso.setEnabled(false);
        txtfHoraSalida.setEnabled(false);

    }

    public void desbloquearCampos() {
        txtfCedula.setEditable(true);
        txtfNombres.setEditable(true);
        txtfApellidos.setEditable(true);
        cmbCampus.setEditable(true);
        cmbLaboratorio.setEditable(true);
        txtfCarrera.setEditable(true);
        cmbModulo.setEditable(true);
        txtfMateria.setEditable(true);
        txtfFecha.setEditable(true);
        txtfHoraIngreso.setEnabled(true);
        txtfHoraSalida.setEnabled(true);
    }

    public String verificarLaboratorio() {
        return txtfCedula.getText();
        
    }

    public void cargarCampos(Laboratorio laboratorio) {

        txtfCedula.setText(laboratorio.getNro_de_ID());
        txtfNombres.setText(laboratorio.getNombres());
        txtfApellidos.setText(laboratorio.getApellidos());
        cmbCampus.setSelectedItem(laboratorio.getCampus());
        cmbLaboratorio.setSelectedItem(laboratorio.getLaboratorio());
        txtfCarrera.setText(laboratorio.getCarrera());
        cmbModulo.setSelectedItem(laboratorio.getModulo());
        txtfMateria.setText(laboratorio.getMateria());
        txtfFecha.setText(laboratorio.getFecha());
        txtfHoraIngreso.setText(laboratorio.getHora_Ingreso());
        txtfHoraSalida.setText(laboratorio.getHora_Salida());
    }

    public String eliminarDocente() {
        return txtfCedula.getText();

    }

    public class OyenteSalir implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

            if (e.getSource() == btnSalir) {
                dispose();
            }
        }

    }
    public class havilitar implements  ActionListener{
        

        @Override
        public void actionPerformed(ActionEvent e) {
          //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      if(e.getSource()==btndesbloquear){
          desbloquearCampos();
          
          
      }
        }
    }
    
   
        

    public static void main(String[] args) {
        new RegistroIngreso();
    }
}
